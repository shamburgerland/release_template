cPanel & WHM product info page
=====
Included is the source code for a cPanel & WHM product information page.  We encourage you to add this page to your site and have included all the information necessary to complete a successful implementation below.



### Site specification ###
-----
• Bootstrap 3.3.7 Framework
• Mobile responsive ready
• More info can be found at https://getbootstrap.com



### Required ###
-----
• Style your own brand
    - Replace "Place Your Header / Footer Brand" to your own header and footer brand
    - Replace "YOUR LOGO" with your own brand logo in assets/img/partnership-logos.png
    - Edit the colors or theme as needed to best align with your brand

• Update Links
    - Update the 3  “I want to Try It Out” links located on this page and have them point to your company’s product section, homepage, or pre-configured shopping cart.  



### Optional ###
-----
• Analytics 
    - Ensure GA code is in between the footer tag and jquery code
    - Set up a conversions goal in GA
    - Ensure that you can track from cPanel & WHM product info page > shopping cart > final purchase

• Upload files to this URL path
    - Preferred URL path: https://www.[yourdomain].com/cpanel-whm/
    - Alternative URL path: https://www.[yourdomain].com/cpanel-whm-info/


-----
Once done, let us know so you can receive a mystery gift: https://cpanel.com/partner-resources/

If you have any questions or concerns, please feel free to reach out to marketing@cpanel.net. 